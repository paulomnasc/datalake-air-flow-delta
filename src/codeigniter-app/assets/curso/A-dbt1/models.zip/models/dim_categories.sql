{{ config(materialized='table') }}

with unique_categories as (
    select distinct category from {{ ref('gold_products') }}
    where category is not null
)

select
    -- Geração da Surrogate Key baseada no nome textual único
    {{ dbt_utils.generate_surrogate_key(['category']) }} as sk_categoria,
    category as nome_categoria
from unique_categories
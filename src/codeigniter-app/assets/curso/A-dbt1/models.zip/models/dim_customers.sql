{{ config(materialized='table') }}

with source_customers as (
    select * from {{ ref('gold_customers') }}
)

select
    -- Geração da Surrogate Key baseada no ID textual natural do Northwind (ex: 'ALFKI')
    {{ dbt_utils.generate_surrogate_key(['customer_id']) }} as sk_cliente,
    customer_id as id_cliente,
    company_name as empresa,
    contact_name as nome_completo,
    contact_title as cargo,
    city as cidade,
    region as regiao,
    country as pais
from source_customers

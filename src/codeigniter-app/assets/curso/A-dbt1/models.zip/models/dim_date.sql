{{ config(materialized='table') }}

with date_series as (
    select 
        cast(range as date) as data_completa
    from range(
        cast('2000-01-01' as date), 
        cast('2030-12-31' as date), 
        interval '1 day'
    )
)

select
    -- Chave de data numérica
    cast(strftime(data_completa, '%Y%m%d') as integer) as sk_data,
    data_completa as data,
    year(data_completa) as ano,
    month(data_completa) as mes,
    day(data_completa) as dia,
    quarter(data_completa) as trimestre,
    dayofweek(data_completa) as dia_semana,
    strftime(data_completa, '%B') as nome_mes,
    case 
        when dayofweek(data_completa) in (0, 6) then 'Fim de Semana' 
        else 'Dia Útil' 
    end as tipo_dia
from date_series
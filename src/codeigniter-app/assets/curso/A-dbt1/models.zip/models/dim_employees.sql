{{ config(materialized='table') }}

with source_employees as (
    select * from {{ ref('gold_employees') }}
)

select
    -- Geração da Surrogate Key
    {{ dbt_utils.generate_surrogate_key(['id']) }} as sk_funcionario,
    id as id_funcionario,
    concat(first_name, ' ', last_name) as nome_completo,
    job_title as cargo,
    business_phone as telefone_comercial,
    email_address as email,
    city as cidade,
    country_region as pais_regiao
from source_employees
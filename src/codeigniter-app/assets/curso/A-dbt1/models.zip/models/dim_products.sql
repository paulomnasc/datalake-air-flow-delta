{{ config(materialized='table') }}

with source_products as (
    select * from {{ ref('gold_products') }}
),

categories as (
    select * from {{ ref('dim_categories') }}
)

select
    -- Geração da Surrogate Key do produto
    {{ dbt_utils.generate_surrogate_key(['p.id']) }} as sk_produto,
    p.id as id_produto,
    p.product_code as codigo_produto,
    p.product_name as nome_produto,
    p.list_price as preco_lista,
    p.standard_cost as custo_padrao,
    case when p.discontinued = 1 then 'Sim' else 'Não' end as descontinuado,
    c.sk_categoria as fk_categoria
from source_products p
left join categories c on p.category = c.nome_categoria
{{ config(materialized='table') }}

with orders as (
    select * from {{ ref('gold_orders') }}
),

order_details as (
    select * from {{ ref('gold_order_details') }}
)

select
    -- 1. Chave Primária da Fato (Surrogate Key composta do pedido + produto)
    {{ dbt_utils.generate_surrogate_key(['od.order_id', 'od.product_id']) }} as sk_venda,
    
    -- 2. Chaves Estrangeiras apontando para as SKs das Dimensões
    {{ dbt_utils.generate_surrogate_key(['o.customer_id']) }} as fk_cliente,
    {{ dbt_utils.generate_surrogate_key(['o.employee_id']) }} as fk_funcionario,
    {{ dbt_utils.generate_surrogate_key(['od.product_id']) }} as fk_produto,
    cast(strftime(o.order_date, '%Y%m%d') as integer) as fk_data_pedido,
    
    -- 3. Dimensões Degeneradas / Identificadores do Negócio (Rastreabilidade)
    od.order_id as id_pedido,
    od.product_id as id_produto,
    
    -- 4. Métricas e Valores do Item
    od.quantity as quantidade,
    od.unit_price as preco_unitario,
    od.discount as desconto,
    
    -- Valor total de frete do pedido (vindo do cabeçalho)
    cast(o.freight as double) as frete_total_pedido,
    
    -- Métricas Analíticas Calculadas
    (od.quantity * od.unit_price) as receita_bruta,
    (od.quantity * od.unit_price * (1 - od.discount)) as receita_liquida

from order_details od
inner join orders o on od.order_id = o.order_id